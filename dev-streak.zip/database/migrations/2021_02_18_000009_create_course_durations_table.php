<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCourseDurationsTable extends Migration
{
    public function up()
    {
        Schema::create('course_durations', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('duration');
            $table->timestamps();
            $table->softDeletes();
        });
    }
}
